const settings = {
  packname: 'Lucky Tech Hub Bot',
  author: '‎',
  botName: "Lucky Tech Hub Bot",
  botOwner: 'L8', // Your name
  ownerNumber: '6289632651616', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "2.1.0",
};

module.exports = settings;
